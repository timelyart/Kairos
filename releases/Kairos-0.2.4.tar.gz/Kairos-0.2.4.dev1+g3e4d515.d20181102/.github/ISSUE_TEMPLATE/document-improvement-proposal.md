---
name: Document improvement proposal
about: Suggest formulation erros, spelling mistakes and / or lack of (clear) content

---

**Type**
Specify what you'd like to improve. Chose from the options below:
* Spelling mistake
* Formulation error
* Documentation needs clarification
* Documentation missing
* Combination of two or more of the above

**Location**
Specify the section and, if applicable, the paragraph.

**Description**
Description of your improvement proposal.
