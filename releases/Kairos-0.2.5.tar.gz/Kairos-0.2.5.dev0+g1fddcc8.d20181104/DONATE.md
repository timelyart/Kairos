# Donate #
Thank you for wanting to support this project.

The best donation you can make in general is by helping others. <br/> 
I'd love to have your help improving this project and you are more than welcome to contribute. 

Alternatively, you can donate using the options below.   

## Bitcoin ##
![bitcoin QR code](img/300_Bitcoin_QR_code.png)
#### 326VU5HbzQuxJo2RaZK4KFgTDHzids68sk ####
## Ethereum ##
![ether QR code](img/300_Ethereum_QR_code.png)
#### 0xdF5b9cbB2731d81F757CBFbD5BdFAdb26445A9dA ####
## Dash ##
![dash QR code](img/300_Dash_QR_code.png)
#### Xhm93azcvzjuSu3zBnCQa6zbBqpXvg1Ttn ####
## Zcash ##
![zcash QR code](img/300_ZCASH_QR_code.png)
#### t1ZGYhoa9NmXRGQF6dYAQApBKG5N4V9yJym ####
